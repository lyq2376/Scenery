"""
    file: scenery.py
    description: To draw a scenery
    language: python 3
    author: Lindy Quach
    section: 3 (Group A)
"""


import turtle


def init():
    """Initialize turtle
    :precondition: Pen is down
    :precondition: Turtle is facing east
    :precondition: Location: (0, 0)
    :precondition: Pensize is 2
    :postcondition: Turtle is initialized
    """
    turtle.down()
    turtle.title('scenery')
    turtle.pensize(2)


def draw_base_side():
    """
    precondition: Pen is down
    precondition: Turtle is facing east
    postcondition: Side of a square has been drawn
    """
    turtle.forward(90)
    turtle.left(90)


def draw_base():
    """
        precondition: Pen is down
        precondition: Location is (0, 0)
        precondition: Turtle is facing east
        postcondition: The base of the house has been drawn
    """
    turtle.fillcolor('turquoise')
    turtle.begin_fill()
    draw_base_side()
    draw_base_side()
    draw_base_side()
    draw_base_side()
    turtle.end_fill()


def draw_roof_side():
    """
        precondition: Pen is down
        precondition: Turtle is facing northeast
        postcondition: Side of a triangle has been drawn
    """
    turtle.forward(90)
    turtle.right(60)


def draw_roof():
    """
        precondition: Pen is down
        precondition: Location is (35,90)
        precondition: Turtle is facing east
        postcondition: A roof has been drawn
    """
    turtle.fillcolor('firebrick')
    turtle.begin_fill()
    draw_roof_side()
    draw_roof_side()
    turtle.right(90)
    turtle.forward(155)
    turtle.end_fill()


def draw_window():
    """
            precondition: Pen is down
            precondition: Turtle is facing east
            postcondition: A window has been drawn
    """
    turtle.fillcolor('azure')
    turtle.begin_fill()
    draw_window_side()
    draw_window_side()
    draw_window_side()
    draw_window_side()
    turtle.end_fill()


def draw_window_side():
    """
            precondition: Pen is up
            precondition: Turtle is facing east
            postcondition: A side of a window has been drawn
    """
    turtle.down()
    turtle.forward(10)
    turtle.right(90)


def move_windows():
    """
                precondition: Pen is down
                precondition: Turtle is facing east
                postcondition: A window has been drawn at a different location
    """
    draw_window()
    turtle.up()
    turtle.forward(25)


def draw_door_side():
    """
                precondition: Pen is up
                precondition: Turtle is facing east
                postcondition: A side of the door has been drawn
    """
    turtle.down()
    turtle.forward(20)
    turtle.left(90)
    turtle.forward(45)
    turtle.left(90)


def draw_door():
    """
                precondition: Pen is up
                precondition: Location: (55, 45)
                precondition: Turtle is facing east
                postcondition: A door has been drawn
    """
    turtle.fillcolor('brown')
    turtle.begin_fill()
    draw_door_side()
    draw_door_side()
    turtle.end_fill()


def draw_house():
    """
            precondition: Pen is down
            precondition: Location is (0, 0)
            precondition: Turtle is facing east
            postcondition: A house has been drawn
    """
    draw_base()
    turtle.up()
    turtle.left(90)
    turtle.forward(90)
    turtle.left(90)
    turtle.forward(35)
    turtle.right(150)
    turtle.down()
    draw_roof()
    turtle.up()
    turtle.right(180)
    turtle.forward(35)
    turtle.right(90)
    turtle.forward(45)
    turtle.left(90)
    turtle.forward(15)
    draw_window()
    turtle.up()
    turtle.left(90)
    turtle.forward(30)
    turtle.right(90)
    move_windows()
    move_windows()
    draw_window()
    turtle.up()
    turtle.right(90)
    turtle.forward(40)
    turtle.right(180)
    draw_window()
    turtle.left(90)
    turtle.up()
    turtle.forward(10)
    turtle.right(90)
    turtle.forward(10)
    turtle.left(90)
    draw_door()


def draw_tree():
    """
            precondition: Pen is down
            precondition: Turtle is facing east
            postcondition: A tree has been drawn
    """
    turtle.fillcolor('saddle brown')
    turtle.begin_fill()
    draw_trunk()
    draw_trunk()
    turtle.end_fill()
    turtle.up()
    turtle.left(90)
    turtle.forward(100)
    turtle.right(90)
    turtle.forward(10)
    turtle.down()
    turtle.fillcolor('forest green')
    turtle.begin_fill()
    turtle.circle(50)
    turtle.end_fill()


def draw_trunk():
    """
                precondition: Pen is up
                precondition: Turtle is facing east
                postcondition: A side of the tree trunk has been drawn
    """
    turtle.down()
    turtle.forward(20)
    turtle.left(90)
    turtle.forward(100)
    turtle.left(90)


def draw_sun():
    """
                precondition: Pen is down
                precondition: Turtle is facing east
                postcondition: A sun has been drawn
    """
    turtle.up()
    turtle.left(90)
    turtle.forward(100)
    turtle.right(95)
    turtle.forward(100)
    turtle.down()
    turtle.fillcolor('yellow')
    turtle.begin_fill()
    turtle.circle(25)
    turtle.end_fill()


def main():
    """
        precondition: Pen is down
        precondition: Location is (0, 0)
        precondition: Turtle is facing east
        postcondition: A scenery has been drawn
    """
    draw_house()
    turtle.up()
    turtle.left(90)
    turtle.forward(45)
    turtle.left(90)
    turtle.forward(125)
    draw_tree()
    turtle.up()
    turtle.forward(10)
    turtle.right(90)
    turtle.forward(100)
    turtle.right(90)
    turtle.forward(325)
    turtle.right(180)
    draw_tree()
    draw_sun()
    turtle.right(90)
    turtle.up()
    turtle.forward(190)
    turtle.left(90)
    turtle.forward(30)
    turtle.done()


if __name__ == '__main__':
    main()
